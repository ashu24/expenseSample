package com.example.expense.resource;

import com.example.expense.dto.ExpenseDto;
import com.example.expense.dto.UserDto;
import com.example.expense.model.User;
import com.example.expense.repository.UserRepository;
import com.example.expense.service.ExpenseService;
import com.example.expense.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ExpenseApi {

    @Autowired
    private UserService userService;

    @Autowired
    private ExpenseService expenseService;

    @Autowired
    private UserRepository userRepository;

    @PostMapping(path="/user") // Map ONLY POST Requests
    public @ResponseBody User addNewUser (@RequestBody UserDto user) {
        //TODO add validation
        return userService.addUser(user);
    }

    @PostMapping(path="/user") // Map ONLY POST Requests
    public @ResponseBody void addNewExpense (@RequestBody ExpenseDto expenseDto) {
        //TODO add validation
        expenseService.addExpense(expenseDto);
    }

}
