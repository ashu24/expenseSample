package com.example.expense.calculate;

import com.example.expense.dto.ExpenseDetailDto;
import com.example.expense.dto.ExpenseDto;
import com.example.expense.model.ExpenseDetail;
import com.example.expense.transformer.ExpenseDetailTransformer;

import java.util.ArrayList;
import java.util.List;

public class EqualExpenseCalculator implements ExpenseCalculator{
    @Override
    public List<ExpenseDetail> calculate(ExpenseDto expenseDto) {
        validate(expenseDto);
        List<ExpenseDetail> result = new ArrayList<>();
        for (ExpenseDetailDto detail : expenseDto.getDetails()) {
            result.add(ExpenseDetailTransformer.transform(detail));
        }
        return result;
        
    }

    private void validate(ExpenseDto expenseDto) {
        validateTotalAmount(expenseDto);
    }

    private void validateTotalAmount(ExpenseDto expenseDto) {
    }
}
