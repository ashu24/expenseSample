package com.example.expense.transformer;

import com.example.expense.dto.ExpenseDetailDto;
import com.example.expense.model.ExpenseDetail;

public class ExpenseDetailTransformer {

    public static ExpenseDetail transform(ExpenseDetailDto dto){
        ExpenseDetail expenseDetail = new ExpenseDetail();
        expenseDetail.setAmount(dto.getAmount());
        expenseDetail.setFromUserId(dto.getFromUserId());
        expenseDetail.setToUserId(dto.getToUserId());
        return expenseDetail;
    }
}
