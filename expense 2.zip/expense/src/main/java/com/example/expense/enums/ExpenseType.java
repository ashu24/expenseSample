package com.example.expense.enums;

public enum ExpenseType {
    EXACT,
    PERCENTAGE,
    EQUAL;
}
