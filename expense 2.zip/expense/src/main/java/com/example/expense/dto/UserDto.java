package com.example.expense.dto;

import lombok.Data;

@Data
public class UserDto {
    private String name;
    private String emailId;
    private String mobile;
}
