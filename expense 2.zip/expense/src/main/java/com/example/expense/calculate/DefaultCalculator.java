package com.example.expense.calculate;

import com.example.expense.dto.ExpenseDto;
import com.example.expense.model.ExpenseDetail;

import java.util.ArrayList;
import java.util.List;

public class DefaultCalculator implements ExpenseCalculator {
    @Override
    public List<ExpenseDetail> calculate(ExpenseDto expenseDto) {
        // TODO throw validation
        return new ArrayList();
    }
}
