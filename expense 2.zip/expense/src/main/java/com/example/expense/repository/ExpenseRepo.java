package com.example.expense.repository;

import com.example.expense.model.Expense;
import org.springframework.data.repository.CrudRepository;

public interface ExpenseRepo extends CrudRepository<Expense, Long> {
}
