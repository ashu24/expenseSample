package com.example.expense.service;

import com.example.expense.ExpenseCalculatorFactory.ExpenseCalculatorFactory;
import com.example.expense.calculate.ExpenseCalculator;
import com.example.expense.dto.ExpenseDto;
import com.example.expense.model.Expense;
import com.example.expense.model.ExpenseDetail;
import com.example.expense.repository.ExpenseDetailRepo;
import com.example.expense.repository.ExpenseRepo;
import com.example.expense.transformer.ExepenseTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseDetailRepo expenseDetailRepo;

    @Autowired
    private ExpenseRepo expenseRepo;

    public void addExpense(ExpenseDto expenseDto) {
        Expense exepnse = ExepenseTransformer.transform(expenseDto);
        ExpenseCalculator expenseCalculator = ExpenseCalculatorFactory.getExpenseCalculator(expenseDto.getType());
        List<ExpenseDetail> expenseDetails = expenseCalculator.calculate(expenseDto);
        Expense savedExpense = expenseRepo.save(exepnse);
        enrichExpenseDetailsForCreation(expenseDetails, savedExpense);
        expenseDetailRepo.saveAll(expenseDetails);
    }

    private void enrichExpenseDetailsForCreation(List<ExpenseDetail> expenseDetails, Expense savedExpense) {
        for (ExpenseDetail expenseDetail : expenseDetails) {
            expenseDetail.setExpenseId(savedExpense.getId());
            expenseDetail.setStatus("CREATED");
        }
    }
}
