package com.example.expense.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ExpenseDetailDto {
    private Long toUserId;
    private Long fromUserId;
    private BigDecimal amount;
}
