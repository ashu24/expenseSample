package com.example.expense.transformer;

import com.example.expense.dto.ExpenseDto;
import com.example.expense.model.Expense;

public class ExepenseTransformer {

    public static Expense transform(ExpenseDto expenseDto){
        Expense expense = new Expense();
        expense.setType(expenseDto.getType());
        expense.setUserId(expenseDto.getUserId());
        return expense;
    }
}
