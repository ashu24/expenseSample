package com.example.expense.calculate;

import com.example.expense.dto.ExpenseDto;
import com.example.expense.model.ExpenseDetail;

import java.util.List;

public class ExactExpenseCalculator implements ExpenseCalculator{
    @Override
    public List<ExpenseDetail> calculate(ExpenseDto expenseDto) {
        return null;
    }
}
