package com.example.expense.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class ExpenseDto {

    private Long userId;
    private BigDecimal total;
    private String type;
    private String status;
    private List<ExpenseDetailDto> details;
}
