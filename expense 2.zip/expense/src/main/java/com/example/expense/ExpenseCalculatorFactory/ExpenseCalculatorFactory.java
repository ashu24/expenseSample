package com.example.expense.ExpenseCalculatorFactory;

import com.example.expense.calculate.*;
import com.example.expense.enums.ExpenseType;

public class ExpenseCalculatorFactory {

    public static ExpenseCalculator getExpenseCalculator(String type){
        switch(type){
            case "EQUAL":
                return new EqualExpenseCalculator();
            case "EXACT":
                return new ExactExpenseCalculator();
            case "PERCENTAGE":
                return new PercentExpenseCalculator();
        }
        return new DefaultCalculator();
    }
}
