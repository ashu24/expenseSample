package com.example.expense.repository;

import com.example.expense.model.ExpenseDetail;
import org.springframework.data.repository.CrudRepository;

public interface ExpenseDetailRepo extends CrudRepository<ExpenseDetail, Long> {

}
